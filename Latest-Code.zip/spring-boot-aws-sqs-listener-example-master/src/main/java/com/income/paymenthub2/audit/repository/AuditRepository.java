package com.income.paymenthub2.audit.repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.income.paymenthub2.audit.dto.Audi_History;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AuditRepository {
    @Autowired
    private DynamoDBMapper dynamoDBMapper;

    public Audi_History saveItem(Audi_History audi_history) {
        dynamoDBMapper.save(audi_history);
        return audi_history;
    }
}
