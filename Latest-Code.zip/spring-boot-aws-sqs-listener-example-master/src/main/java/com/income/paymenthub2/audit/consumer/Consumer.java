package com.income.paymenthub2.audit.consumer;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.aws.messaging.listener.annotation.SqsListener;
import org.springframework.messaging.handler.annotation.MessageExceptionHandler;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class Consumer {

	/*@SqsListener(value= "https://sqs.ap-southeast-1.amazonaws.com/025179857257/FirstQueue.fifo")
	public void recievePhubdata(Student student) {
		//log.info("Message Received using SQS headers " + headers);
		try{
			log.info("Message Received using SQS student " + student);
		}catch (Exception ex){
			log.error(" Error Message Received using SQS student ");
		}
	}*/
	@SqsListener(value= "https://sqs.ap-southeast-1.amazonaws.com/025179857257/FirstQueue.fifo")
	public void recievePhubdata(String student) {
		//log.info("Message Received using SQS headers " + headers);
		try{
			log.info("Message Received using SQS student " + student);
		}catch (Exception ex){
			log.error(" Error Message Received using SQS student ");
		}
	}
	@MessageExceptionHandler(Exception.class)
	void handleException(Exception e) {
	}
}
