package io.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsSqsSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
