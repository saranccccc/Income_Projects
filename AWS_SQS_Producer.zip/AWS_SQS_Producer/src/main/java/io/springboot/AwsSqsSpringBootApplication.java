package io.springboot;

import com.amazonaws.auth.BasicAWSCredentials;
import io.springboot.model.Student;
import io.springboot.util.SQSUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.aws.core.env.ResourceIdResolver;
import org.springframework.cloud.aws.messaging.config.QueueMessageHandlerFactory;
import org.springframework.cloud.aws.messaging.core.QueueMessagingTemplate;
import org.springframework.context.annotation.Bean;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSAsync;
import com.amazonaws.services.sqs.AmazonSQSAsyncClientBuilder;

import java.util.UUID;

@SpringBootApplication
public class AwsSqsSpringBootApplication implements ApplicationRunner {

	 public static void main(String[] args) {
		SpringApplication.run(AwsSqsSpringBootApplication.class, args);
	 }
	
	 @Bean
	 public AmazonSQSAsync amazonSQSAsync() {
	    return AmazonSQSAsyncClientBuilder.defaultClient();
	 }
	 
	 @Bean
	 public QueueMessagingTemplate queueMessagingTemplate(AmazonSQSAsync amazonSqs) {
	    return new QueueMessagingTemplate(amazonSqs);
	 }

	@Value("${aws.accessKey}")
	private String awsAccessKey;
	@Value("${aws.secretKey}")
	private String awsSecretKey;

	@Autowired
	SQSUtil sqsUtil;

	@Bean
	public BasicAWSCredentials amazonAWSCredentials() {
		return new BasicAWSCredentials(awsAccessKey, awsSecretKey);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		System.out.println("/send ");
		Student student = new Student();
		student.setAge(10);
		student.setId(1);
		student.setName(UUID.randomUUID().toString());
		sqsUtil.sendSQSMessage(student);

	}
}
