package io.springboot.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.aws.messaging.listener.annotation.SqsListener;
import org.springframework.web.bind.annotation.*;

import io.springboot.model.Student;
import io.springboot.util.SQSUtil;

import java.util.Random;
import java.util.UUID;

@RestController
@RequestMapping(value="/sqs")
public class SqsResource {

	@Autowired
	SQSUtil sqsUtil;
	
	@RequestMapping(value = "/sendMessageQueue", method = RequestMethod.POST)
    public @ResponseBody void write(@RequestBody Student student){
		
			sqsUtil.sendSQSMessage(student);

	}

	@GetMapping("/send")
	public String sendMsg(){
		System.out.println("/send ");
		Student student = new Student();
		student.setAge(10);
		student.setId(1);
		student.setName(UUID.randomUUID().toString());
		sqsUtil.sendSQSMessage(student);
		//sqsUtil.sendToFifoQueue("testing","che","cec");
		return "success";
	}
	
}