package com.income.paymenthub2.audit.repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.income.paymenthub2.audit.entity.PaymentLogEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
@Slf4j
public class PaymentLogRepository {
    @Autowired
    private DynamoDBMapper dynamoDBMapper;

    public PaymentLogEntity saveItem(PaymentLogEntity paymentLogEntity) {
        dynamoDBMapper.save(paymentLogEntity);
        log.info("4. Audit data saved in Payment Log Table " + paymentLogEntity.toString());
        return paymentLogEntity;
    }
}
