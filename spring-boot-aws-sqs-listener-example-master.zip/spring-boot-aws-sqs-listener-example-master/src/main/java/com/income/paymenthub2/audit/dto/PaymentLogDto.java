package com.income.paymenthub2.audit.dto;

import lombok.Data;

@Data
public class PaymentLogDto {
    private String id;
    private String dateTime;
    private String description;
    private String from;
    private String to;
    private String msgUid;
    private String requestData;
    private String responseData;
    private String applicationID;
    private String cognitoAccessToken;
    private String createdDateTime;
    private String others;
}
