package com.income.paymenthub2.audit.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.income.paymenthub2.audit.dto.PaymentLogDto;
import com.income.paymenthub2.audit.entity.PaymentLogEntity;
import com.income.paymenthub2.audit.model.AwsProperty;
import com.income.paymenthub2.audit.repository.PaymentLogRepository;
import com.income.paymenthub2.audit.service.QueueService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.aws.messaging.core.QueueMessagingTemplate;
import org.springframework.cloud.aws.messaging.core.SqsMessageHeaders;
import org.springframework.cloud.aws.messaging.listener.SqsMessageDeletionPolicy;
import org.springframework.cloud.aws.messaging.listener.annotation.SqsListener;
import org.springframework.messaging.handler.annotation.MessageExceptionHandler;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class QueueServiceImpl implements QueueService {
    private final QueueMessagingTemplate queueMessagingTemplate;
    private final AwsProperty awsProperty;
    private final PaymentLogRepository paymentLogRepository;

    @Override
    @SqsListener(value = "https://sqs.ap-southeast-1.amazonaws.com/025179857257/FirstQueue.fifo",deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
    public void receiveAuditData(String auditData) {
        //log.info("Message Received using SQS headers " + headers);
        try {
            log.info("3. Message Received by the Audit Queue in String {} : " , auditData);
            ObjectMapper mapper = new ObjectMapper();
            PaymentLogDto paymentLogDto= mapper.readValue(auditData,PaymentLogDto.class);
            PaymentLogEntity paymentLogEntity = new PaymentLogEntity();
            paymentLogEntity.setApplicationID(paymentLogDto.getApplicationID());
            paymentLogEntity.setId(paymentLogDto.getId());
            paymentLogEntity.setFrom(paymentLogDto.getFrom());
            paymentLogEntity.setDescription(paymentLogDto.getDescription());
            paymentLogEntity.setDateTime(paymentLogDto.getDateTime());
            paymentLogEntity.setTo(paymentLogDto.getTo());
            paymentLogEntity.setMsgUid(paymentLogDto.getMsgUid());
            paymentLogEntity.setRequestData(paymentLogDto.getRequestData());
            paymentLogEntity.setResponseData(paymentLogDto.getResponseData());
            paymentLogEntity.setCognitoAccessToken(paymentLogDto.getCognitoAccessToken());
            paymentLogEntity.setCreatedDateTime(paymentLogDto.getCreatedDateTime());
            paymentLogEntity.setOthers(paymentLogDto.getOthers());
            paymentLogRepository.saveItem(paymentLogEntity);

        } catch (Exception ex) {
            log.error(" Error Message Received by the Audit Queue {}", ex.getMessage());
        }
    }

    @Override
    public void sendAuditData(PaymentLogDto auditData, String msgGrpId, String msgDupId) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            String jsonString = mapper.writeValueAsString(auditData);
            //	queueMessagingTemplate.send(endPoint, MessageBuilder.withPayload(jsonString).build());

            // Message for FIFO Queue
            Map<String, Object> headers = new HashMap<>();
            headers.put(SqsMessageHeaders.SQS_GROUP_ID_HEADER, "1");
            headers.put(SqsMessageHeaders.SQS_DEDUPLICATION_ID_HEADER, "2");
            queueMessagingTemplate.send(awsProperty.getQueueUri(),
                    MessageBuilder.withPayload(jsonString).copyHeaders(headers).build());

            log.info("2. Message saved in Queue successfully as jsonString " , jsonString);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @MessageExceptionHandler(Exception.class)
    void handleException(Exception e) {
    }
}
