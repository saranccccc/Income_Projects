package com.income.paymenthub2.audit.controller;

import com.income.paymenthub2.audit.dto.PaymentLogDto;
import com.income.paymenthub2.audit.service.QueueService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequiredArgsConstructor
public class TestController {

    private final QueueService queueService;

    @PostMapping("/auditLog")
    public ResponseEntity saveAuditLod(@RequestBody PaymentLogDto paymentLogDto) {
        log.info("1. sending audit log to queue with PaymentLogDto {} ",paymentLogDto.toString());
        queueService.sendAuditData(paymentLogDto,"1","1");
        return ResponseEntity.ok("sent audit log to queue successfully");

    }
}
