package com.income.paymenthub2.audit;

import com.income.paymenthub2.audit.entity.PaymentLogEntity;
import com.income.paymenthub2.audit.repository.PaymentLogRepository;
import com.income.paymenthub2.audit.service.QueueService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.aws.autoconfigure.context.ContextStackAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication(exclude = { ContextStackAutoConfiguration.class })
@ComponentScan(basePackages = "com.income.paymenthub2.*")
@Slf4j
public class Application  {



	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}
