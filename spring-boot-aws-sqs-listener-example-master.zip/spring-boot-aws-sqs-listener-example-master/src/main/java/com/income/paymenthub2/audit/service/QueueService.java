package com.income.paymenthub2.audit.service;

import com.income.paymenthub2.audit.dto.PaymentLogDto;

public interface QueueService {
     void receiveAuditData(String auditData);
     void sendAuditData(PaymentLogDto auditData, String msgGrpId, String msgDupId);
}
