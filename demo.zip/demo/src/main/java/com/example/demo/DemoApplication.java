package com.example.demo;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.sqs.AmazonSQSAsync;
import com.amazonaws.services.sqs.AmazonSQSAsyncClientBuilder;
import io.awspring.cloud.sqs.operations.SqsTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;

@SpringBootApplication
public class DemoApplication implements ApplicationRunner {
	@Value("${aws.accessKey}")
	private String awsAccessKey;
	@Value("${aws.secretKey}")
	private String awsSecretKey;

	// Value is populated by the region code.
	@Value("${cloud.aws.region.static}")
	private String region;
	private static final String QUEUE_NAME = "https://sqs.ap-southeast-1.amazonaws.com/025179857257/Testqueue";
	@Autowired
	private  MessageSender messageSender;

	@Autowired
	private MessageSenderWithTemplate messageSenderWithTemplate;
	@Autowired
	private SqsTemplate sqsTemplate;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		messageSender.send("test message");
		//messageSenderWithTemplate.sendToFifoQueue("test message","id1","id-dup1");
		sqsAsyncClient.sendMessage(SendMessageRequest.builder()
				.queueUrl(QUEUE_NAME)
				.messageBody("Hello world!")
				.delaySeconds(10)
				.build());
		sqsTemplate.send(QUEUE_NAME,"test sqs templater");
	}


}
